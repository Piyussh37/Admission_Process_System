 # R. C. Patel Institute of Technology was set up as a part of the self-powered plans of Shirpur Education 
                # \nSociety i