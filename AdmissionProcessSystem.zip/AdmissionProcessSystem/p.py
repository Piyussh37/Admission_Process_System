h = map(int,input().split())
k = list[h]
print(k)